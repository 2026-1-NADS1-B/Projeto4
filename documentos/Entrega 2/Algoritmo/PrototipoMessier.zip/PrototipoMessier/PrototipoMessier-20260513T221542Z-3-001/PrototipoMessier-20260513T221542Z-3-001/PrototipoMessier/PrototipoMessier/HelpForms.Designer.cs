﻿namespace PrototipoMessier
{
    partial class HelpForms
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblHelp = new Label();
            txtHelp = new TextBox();
            btnJogos = new Button();
            btnPacote = new Button();
            SuspendLayout();
            // 
            // lblHelp
            // 
            lblHelp.AutoSize = true;
            lblHelp.Font = new Font("Sylfaen", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblHelp.Location = new Point(308, 20);
            lblHelp.Name = "lblHelp";
            lblHelp.Size = new Size(150, 16);
            lblHelp.TabIndex = 0;
            lblHelp.Text = "Help do Sistema Messier";
            // 
            // txtHelp
            // 
            txtHelp.Location = new Point(12, 113);
            txtHelp.Multiline = true;
            txtHelp.Name = "txtHelp";
            txtHelp.ScrollBars = ScrollBars.Vertical;
            txtHelp.Size = new Size(778, 325);
            txtHelp.TabIndex = 1;
            txtHelp.TextChanged += textBox1_TextChanged;
            // 
            // btnJogos
            // 
            btnJogos.Location = new Point(12, 67);
            btnJogos.Name = "btnJogos";
            btnJogos.Size = new Size(116, 23);
            btnJogos.TabIndex = 2;
            btnJogos.Text = "Cadastrar Jogos";
            btnJogos.UseVisualStyleBackColor = true;
            btnJogos.Click += btnJogos_Click;
            // 
            // btnPacote
            // 
            btnPacote.BackColor = SystemColors.ControlLightLight;
            btnPacote.Location = new Point(167, 67);
            btnPacote.Name = "btnPacote";
            btnPacote.Size = new Size(116, 23);
            btnPacote.TabIndex = 3;
            btnPacote.Text = "Cadastrar Pacotes";
            btnPacote.UseVisualStyleBackColor = false;
            btnPacote.Click += btnPacote_Click;
            // 
            // HelpForms
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(802, 450);
            Controls.Add(btnPacote);
            Controls.Add(btnJogos);
            Controls.Add(txtHelp);
            Controls.Add(lblHelp);
            Name = "HelpForms";
            Text = "HelpForms";
            Load += HelpForms_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblHelp;
        private TextBox txtHelp;
        private Button btnJogos;
        private Button btnPacote;
    }
}