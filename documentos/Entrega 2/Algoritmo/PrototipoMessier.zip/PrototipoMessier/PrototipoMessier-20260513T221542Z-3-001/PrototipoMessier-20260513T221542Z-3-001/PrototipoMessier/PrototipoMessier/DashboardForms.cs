﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrototipoMessier
{
    public partial class DashboardForms : Form
    {
        public DashboardForms()
        {
            InitializeComponent();
        }

        private void DashboardForms_Load(object sender, EventArgs e)
        {
            dtpData.Enabled = false;
            
            dtpData.CalendarMonthBackground = Color.White;

            this.BackColor = Color.FromArgb(240, 242, 245);


            string[] titulosCards = { "Escolas Ativas", "Pacote Mais Vendido", "Alertas de Limite" };
            string[] valoresCards = { "12", "Premium", "02" };
            Color[] coresCards = { Color.FromArgb(0, 0, 128), Color.DimGray, Color.Firebrick };

            for (int i = 0; i < titulosCards.Length; i++)
            {
                Panel card = new Panel();
                card.Size = new Size(240, 100);
                card.BackColor = Color.White;
                card.BorderStyle = BorderStyle.None;
                card.Margin = new Padding(10, 10, 20, 10);


                Panel barraCor = new Panel();
                barraCor.Size = new Size(8, 100);
                barraCor.Location = new Point(0, 0);
                barraCor.BackColor = coresCards[i];
                card.Controls.Add(barraCor);

                Label lblTitulo = new Label();
                lblTitulo.Text = titulosCards[i];
                lblTitulo.Font = new Font("Segoe UI", 10, FontStyle.Regular);
                lblTitulo.ForeColor = Color.Gray;
                lblTitulo.Location = new Point(20, 20);
                lblTitulo.Size = new Size(190, 20);
                card.Controls.Add(lblTitulo);

                Label lblValor = new Label();
                lblValor.Text = valoresCards[i];
                lblValor.Font = new Font("Segoe UI", 20, FontStyle.Bold);
                lblValor.ForeColor = coresCards[i];
                lblValor.Location = new Point(20, 45);
                lblValor.Size = new Size(190, 40);
                card.Controls.Add(lblValor);

                flpCards.Controls.Add(card);
            }


            dgvAlertas.BackgroundColor = Color.White;
            dgvAlertas.BorderStyle = BorderStyle.None;
            dgvAlertas.RowHeadersVisible = false;
            dgvAlertas.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvAlertas.AllowUserToAddRows = false;


            dgvAlertas.RowTemplate.Height = 35;

            dgvAlertas.Columns.Add("Escola", "Escola em Risco");
            dgvAlertas.Columns.Add("Pacote", "Pacote");
            dgvAlertas.Columns.Add("Consumo", "Consumo Atual / Limite");
            dgvAlertas.Columns.Add("Status", "Status");

            dgvAlertas.Rows.Add("Escola Estadual Prof. José", "Intermediário", "245 / 250 acessos", "98% (Crítico)");
            dgvAlertas.Rows.Add("Colégio Avanço Mater", "Premium", "480 / 500 acessos", "96% (Atenção)");
            dgvAlertas.Rows.Add("Instituto Pequeno Príncipe", "Básico", "95 / 100 acessos", "95% (Atenção)");

            dgvAlertas.EnableHeadersVisualStyles = false;
            dgvAlertas.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(0, 0, 128);
            dgvAlertas.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
            dgvAlertas.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 10, FontStyle.Bold);


            Label lblAtalhos = new Label();
            lblAtalhos.Text = "Ações Rápidas do Sistema:";
            lblAtalhos.Font = new Font("Segoe UI", 11, FontStyle.Bold);
            lblAtalhos.Location = new Point(dgvAlertas.Location.X, dgvAlertas.Bottom + 20);
            lblAtalhos.Size = new Size(300, 25);
            this.Controls.Add(lblAtalhos);

            Button btnIrRelatorios = new Button();
            btnIrRelatorios.Text = "Ver Relatórios Completos";
            btnIrRelatorios.Font = new Font("Segoe UI", 9, FontStyle.Bold);
            btnIrRelatorios.Size = new Size(180, 40);
            btnIrRelatorios.Location = new Point(dgvAlertas.Location.X, lblAtalhos.Bottom + 10);
            btnIrRelatorios.FlatStyle = FlatStyle.Flat;
            btnIrRelatorios.BackColor = Color.White;
            btnIrRelatorios.ForeColor = Color.FromArgb(0, 0, 128);
            btnIrRelatorios.FlatAppearance.BorderColor = Color.FromArgb(0, 0, 128);
            btnIrRelatorios.Click += (s, ev) => {
                
                RelEscolaForms telaRelatorios = new RelEscolaForms();

                
                telaRelatorios.Show();

            };
            

            this.Controls.Add(btnIrRelatorios);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
