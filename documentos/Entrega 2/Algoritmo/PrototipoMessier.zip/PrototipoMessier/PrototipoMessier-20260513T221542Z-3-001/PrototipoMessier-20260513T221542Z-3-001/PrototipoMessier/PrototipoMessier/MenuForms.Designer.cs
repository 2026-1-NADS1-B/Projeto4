﻿namespace PrototipoMessier
{
    partial class Form1 : Form
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            BtnCatalogo = new Button();
            panel1 = new Panel();
            btnRelatorios = new Button();
            btnEscolas = new Button();
            btnGestaoDePacotes = new Button();
            btnSair = new Button();
            btnCadastroDeGames = new Button();
            BtnDashboard = new Button();
            pnlConteudo = new Panel();
            pictureBox1 = new PictureBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // BtnCatalogo
            // 
            BtnCatalogo.BackColor = Color.Navy;
            BtnCatalogo.FlatAppearance.BorderSize = 0;
            BtnCatalogo.FlatAppearance.MouseDownBackColor = Color.FromArgb(0, 0, 64);
            BtnCatalogo.FlatAppearance.MouseOverBackColor = Color.FromArgb(0, 0, 192);
            BtnCatalogo.FlatStyle = FlatStyle.Flat;
            BtnCatalogo.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BtnCatalogo.ForeColor = Color.White;
            BtnCatalogo.Location = new Point(77, 483);
            BtnCatalogo.Name = "BtnCatalogo";
            BtnCatalogo.Size = new Size(152, 46);
            BtnCatalogo.TabIndex = 1;
            BtnCatalogo.Text = "🚀 Catalogo de Jogos";
            BtnCatalogo.TextAlign = ContentAlignment.MiddleLeft;
            BtnCatalogo.UseVisualStyleBackColor = false;
            BtnCatalogo.Click += btnCatalogo_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.DodgerBlue;
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(btnRelatorios);
            panel1.Controls.Add(btnEscolas);
            panel1.Controls.Add(btnGestaoDePacotes);
            panel1.Controls.Add(btnSair);
            panel1.Controls.Add(btnCadastroDeGames);
            panel1.Controls.Add(BtnDashboard);
            panel1.Controls.Add(BtnCatalogo);
            panel1.Location = new Point(-8, -7);
            panel1.Name = "panel1";
            panel1.Size = new Size(306, 800);
            panel1.TabIndex = 2;
            // 
            // btnRelatorios
            // 
            btnRelatorios.BackColor = Color.Navy;
            btnRelatorios.FlatAppearance.BorderSize = 0;
            btnRelatorios.FlatAppearance.MouseDownBackColor = Color.FromArgb(0, 0, 64);
            btnRelatorios.FlatAppearance.MouseOverBackColor = Color.Blue;
            btnRelatorios.FlatStyle = FlatStyle.Flat;
            btnRelatorios.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnRelatorios.ForeColor = SystemColors.Control;
            btnRelatorios.Location = new Point(77, 563);
            btnRelatorios.Name = "btnRelatorios";
            btnRelatorios.Size = new Size(152, 45);
            btnRelatorios.TabIndex = 10;
            btnRelatorios.Text = "📉 Relatórios";
            btnRelatorios.TextAlign = ContentAlignment.MiddleLeft;
            btnRelatorios.UseVisualStyleBackColor = false;
            btnRelatorios.Click += btnRelatorios_Click;
            // 
            // btnEscolas
            // 
            btnEscolas.BackColor = Color.Navy;
            btnEscolas.FlatAppearance.BorderSize = 0;
            btnEscolas.FlatAppearance.MouseDownBackColor = Color.FromArgb(0, 0, 64);
            btnEscolas.FlatAppearance.MouseOverBackColor = Color.Blue;
            btnEscolas.FlatStyle = FlatStyle.Flat;
            btnEscolas.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnEscolas.ForeColor = SystemColors.Control;
            btnEscolas.Location = new Point(77, 402);
            btnEscolas.Name = "btnEscolas";
            btnEscolas.Size = new Size(152, 45);
            btnEscolas.TabIndex = 9;
            btnEscolas.Text = "🌐 Escolas e IPs";
            btnEscolas.TextAlign = ContentAlignment.MiddleLeft;
            btnEscolas.UseVisualStyleBackColor = false;
            btnEscolas.Click += btnEscolas_Click;
            // 
            // btnGestaoDePacotes
            // 
            btnGestaoDePacotes.BackColor = Color.Navy;
            btnGestaoDePacotes.FlatAppearance.BorderSize = 0;
            btnGestaoDePacotes.FlatAppearance.MouseDownBackColor = Color.FromArgb(0, 0, 64);
            btnGestaoDePacotes.FlatAppearance.MouseOverBackColor = Color.Blue;
            btnGestaoDePacotes.FlatStyle = FlatStyle.Flat;
            btnGestaoDePacotes.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnGestaoDePacotes.ForeColor = SystemColors.Control;
            btnGestaoDePacotes.Location = new Point(77, 317);
            btnGestaoDePacotes.Name = "btnGestaoDePacotes";
            btnGestaoDePacotes.Size = new Size(152, 45);
            btnGestaoDePacotes.TabIndex = 8;
            btnGestaoDePacotes.Text = "📦 Gestão de Pacotes";
            btnGestaoDePacotes.TextAlign = ContentAlignment.MiddleLeft;
            btnGestaoDePacotes.UseVisualStyleBackColor = false;
            btnGestaoDePacotes.Click += btnGestaoDePacotes_Click;
            // 
            // btnSair
            // 
            btnSair.BackColor = Color.Navy;
            btnSair.FlatAppearance.BorderSize = 0;
            btnSair.FlatAppearance.MouseDownBackColor = Color.FromArgb(0, 0, 64);
            btnSair.FlatAppearance.MouseOverBackColor = Color.Blue;
            btnSair.FlatStyle = FlatStyle.Flat;
            btnSair.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSair.ForeColor = SystemColors.Control;
            btnSair.Location = new Point(77, 717);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(152, 30);
            btnSair.TabIndex = 8;
            btnSair.Text = "⬅️ Sair";
            btnSair.TextAlign = ContentAlignment.MiddleLeft;
            btnSair.UseVisualStyleBackColor = false;
            btnSair.Click += btnSair_Click;
            // 
            // btnCadastroDeGames
            // 
            btnCadastroDeGames.BackColor = Color.Navy;
            btnCadastroDeGames.FlatAppearance.BorderSize = 0;
            btnCadastroDeGames.FlatAppearance.MouseDownBackColor = Color.FromArgb(0, 0, 64);
            btnCadastroDeGames.FlatAppearance.MouseOverBackColor = Color.Blue;
            btnCadastroDeGames.FlatStyle = FlatStyle.Flat;
            btnCadastroDeGames.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCadastroDeGames.ForeColor = SystemColors.Control;
            btnCadastroDeGames.Location = new Point(77, 239);
            btnCadastroDeGames.Name = "btnCadastroDeGames";
            btnCadastroDeGames.Size = new Size(152, 45);
            btnCadastroDeGames.TabIndex = 8;
            btnCadastroDeGames.Text = "🎮 Cadastro de Games";
            btnCadastroDeGames.TextAlign = ContentAlignment.MiddleLeft;
            btnCadastroDeGames.UseVisualStyleBackColor = false;
            btnCadastroDeGames.Click += btnCadastroDeGames_Click;
            // 
            // BtnDashboard
            // 
            BtnDashboard.BackColor = Color.Navy;
            BtnDashboard.FlatAppearance.BorderSize = 0;
            BtnDashboard.FlatAppearance.MouseDownBackColor = Color.FromArgb(0, 0, 64);
            BtnDashboard.FlatAppearance.MouseOverBackColor = Color.Blue;
            BtnDashboard.FlatStyle = FlatStyle.Flat;
            BtnDashboard.Font = new Font("Segoe UI Emoji", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BtnDashboard.ForeColor = SystemColors.Control;
            BtnDashboard.Location = new Point(77, 163);
            BtnDashboard.Name = "BtnDashboard";
            BtnDashboard.Size = new Size(152, 45);
            BtnDashboard.TabIndex = 3;
            BtnDashboard.Text = "🏠 Dashboard";
            BtnDashboard.TextAlign = ContentAlignment.MiddleLeft;
            BtnDashboard.UseVisualStyleBackColor = false;
            BtnDashboard.Click += btnDashboard_Click;
            // 
            // pnlConteudo
            // 
            pnlConteudo.BackColor = Color.White;
            pnlConteudo.Location = new Point(292, -4);
            pnlConteudo.Name = "pnlConteudo";
            pnlConteudo.Size = new Size(1193, 772);
            pnlConteudo.TabIndex = 3;
            // 
            // pictureBox1
            // 
            pictureBox1.ErrorImage = null;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(40, 19);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(220, 114);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 11;
            pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1479, 764);
            Controls.Add(pnlConteudo);
            Controls.Add(panel1);
            Margin = new Padding(3, 2, 3, 2);
            Name = "Form1";
            Text = "Prototipo Messier";
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion


        private Button BtnCatalogo;
        private Panel panel1;
        private Button BtnDashboard;
        private Button btnCadastroDeGames;
        private Button btnEscolas;
        private Button btnGestaoDePacotes;
        private Button btnSair;
        private Button btnRelatorios;
        private Panel pnlConteudo;
        private PictureBox pictureBox1;
    }
}
