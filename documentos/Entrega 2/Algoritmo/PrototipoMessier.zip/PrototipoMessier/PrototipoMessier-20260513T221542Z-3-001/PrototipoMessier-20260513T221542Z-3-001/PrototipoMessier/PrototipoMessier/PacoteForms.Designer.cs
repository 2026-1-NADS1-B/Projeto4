﻿namespace PrototipoMessier
{
    partial class PacoteForms
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            txtNomePacote = new TextBox();
            txtID = new TextBox();
            LblNomePacote = new Label();
            label3 = new Label();
            ChkJogosPacotes = new CheckedListBox();
            grdPacotes = new DataGridView();
            ID = new DataGridViewTextBoxColumn();
            Pacote = new DataGridViewTextBoxColumn();
            Acessos = new DataGridViewTextBoxColumn();
            Preco = new DataGridViewTextBoxColumn();
            JogosPacote = new DataGridViewTextBoxColumn();
            btnSalvar = new Button();
            btnNovo = new Button();
            Lbl_IdPacote = new Label();
            LblAcessosPacote = new Label();
            TxtAcessosPacote = new TextBox();
            LblPrecosPacote = new Label();
            TxtPrecoPacote = new TextBox();
            ((System.ComponentModel.ISupportInitialize)grdPacotes).BeginInit();
            SuspendLayout();
            // 
            // txtNomePacote
            // 
            txtNomePacote.Location = new Point(198, 102);
            txtNomePacote.Margin = new Padding(3, 2, 3, 2);
            txtNomePacote.Name = "txtNomePacote";
            txtNomePacote.PlaceholderText = "Digite o nome do Pacote";
            txtNomePacote.Size = new Size(409, 23);
            txtNomePacote.TabIndex = 8;
            txtNomePacote.TextChanged += txtNomePacote_TextChanged;
            // 
            // txtID
            // 
            txtID.Location = new Point(198, 44);
            txtID.Margin = new Padding(3, 2, 3, 2);
            txtID.Name = "txtID";
            txtID.PlaceholderText = "Digite seu ID";
            txtID.Size = new Size(409, 23);
            txtID.TabIndex = 7;
            txtID.TextChanged += txtID_TextChanged;
            // 
            // LblNomePacote
            // 
            LblNomePacote.AutoSize = true;
            LblNomePacote.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LblNomePacote.ForeColor = SystemColors.ControlText;
            LblNomePacote.Location = new Point(40, 102);
            LblNomePacote.Name = "LblNomePacote";
            LblNomePacote.Size = new Size(141, 21);
            LblNomePacote.TabIndex = 6;
            LblNomePacote.Text = "Nome do Pacote:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(43, 333);
            label3.Name = "label3";
            label3.Size = new Size(138, 21);
            label3.TabIndex = 9;
            label3.Text = "Jogos do Pacote:";
            // 
            // ChkJogosPacotes
            // 
            ChkJogosPacotes.BackColor = SystemColors.ActiveCaption;
            ChkJogosPacotes.FormattingEnabled = true;
            ChkJogosPacotes.Items.AddRange(new object[] { "Minecraft", "Forza", "CS", "FIFA", "Zelda" });
            ChkJogosPacotes.Location = new Point(198, 333);
            ChkJogosPacotes.Margin = new Padding(3, 2, 3, 2);
            ChkJogosPacotes.Name = "ChkJogosPacotes";
            ChkJogosPacotes.Size = new Size(409, 94);
            ChkJogosPacotes.TabIndex = 10;
            ChkJogosPacotes.SelectedIndexChanged += checkedListBox1_SelectedIndexChanged;
            // 
            // grdPacotes
            // 
            grdPacotes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            grdPacotes.Columns.AddRange(new DataGridViewColumn[] { ID, Pacote, Acessos, Preco, JogosPacote });
            grdPacotes.Location = new Point(43, 448);
            grdPacotes.Margin = new Padding(3, 2, 3, 2);
            grdPacotes.Name = "grdPacotes";
            grdPacotes.RowHeadersWidth = 51;
            grdPacotes.Size = new Size(654, 141);
            grdPacotes.TabIndex = 11;
            grdPacotes.CellContentClick += grdPacotes_CellContentClick;
            // 
            // ID
            // 
            ID.HeaderText = "ID";
            ID.MaxInputLength = 3;
            ID.MinimumWidth = 6;
            ID.Name = "ID";
            ID.ReadOnly = true;
            ID.Width = 60;
            // 
            // Pacote
            // 
            Pacote.HeaderText = "Pacote";
            Pacote.MaxInputLength = 20;
            Pacote.MinimumWidth = 6;
            Pacote.Name = "Pacote";
            Pacote.ReadOnly = true;
            Pacote.Width = 200;
            // 
            // Acessos
            // 
            Acessos.HeaderText = "Acessos";
            Acessos.Name = "Acessos";
            // 
            // Preco
            // 
            Preco.HeaderText = "Preço";
            Preco.Name = "Preco";
            Preco.Resizable = DataGridViewTriState.True;
            Preco.SortMode = DataGridViewColumnSortMode.NotSortable;
            // 
            // JogosPacote
            // 
            JogosPacote.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            JogosPacote.DefaultCellStyle = dataGridViewCellStyle1;
            JogosPacote.HeaderText = "Jogos Pacote";
            JogosPacote.Name = "JogosPacote";
            JogosPacote.Resizable = DataGridViewTriState.True;
            // 
            // btnSalvar
            // 
            btnSalvar.Location = new Point(615, 593);
            btnSalvar.Margin = new Padding(3, 2, 3, 2);
            btnSalvar.Name = "btnSalvar";
            btnSalvar.Size = new Size(82, 22);
            btnSalvar.TabIndex = 13;
            btnSalvar.Text = "Salvar";
            btnSalvar.UseVisualStyleBackColor = true;
            btnSalvar.Click += btnSalvar_Click;
            // 
            // btnNovo
            // 
            btnNovo.Location = new Point(43, 593);
            btnNovo.Margin = new Padding(3, 2, 3, 2);
            btnNovo.Name = "btnNovo";
            btnNovo.Size = new Size(82, 22);
            btnNovo.TabIndex = 12;
            btnNovo.Text = "Novo";
            btnNovo.UseVisualStyleBackColor = true;
            btnNovo.Click += btnNovo_Click;
            // 
            // Lbl_IdPacote
            // 
            Lbl_IdPacote.AutoSize = true;
            Lbl_IdPacote.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Lbl_IdPacote.Location = new Point(43, 46);
            Lbl_IdPacote.Name = "Lbl_IdPacote";
            Lbl_IdPacote.Size = new Size(31, 21);
            Lbl_IdPacote.TabIndex = 5;
            Lbl_IdPacote.Text = "ID:";
            // 
            // LblAcessosPacote
            // 
            LblAcessosPacote.AutoSize = true;
            LblAcessosPacote.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LblAcessosPacote.Location = new Point(40, 178);
            LblAcessosPacote.Name = "LblAcessosPacote";
            LblAcessosPacote.Size = new Size(148, 21);
            LblAcessosPacote.TabIndex = 14;
            LblAcessosPacote.Text = "Limite de Acessos:";
            // 
            // TxtAcessosPacote
            // 
            TxtAcessosPacote.Location = new Point(198, 176);
            TxtAcessosPacote.Name = "TxtAcessosPacote";
            TxtAcessosPacote.PlaceholderText = "Limite de acessos mensal";
            TxtAcessosPacote.Size = new Size(409, 23);
            TxtAcessosPacote.TabIndex = 15;
            // 
            // LblPrecosPacote
            // 
            LblPrecosPacote.AutoSize = true;
            LblPrecosPacote.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LblPrecosPacote.Location = new Point(43, 248);
            LblPrecosPacote.Name = "LblPrecosPacote";
            LblPrecosPacote.Size = new Size(116, 21);
            LblPrecosPacote.TabIndex = 16;
            LblPrecosPacote.Text = "Preço Mensal:";
            // 
            // TxtPrecoPacote
            // 
            TxtPrecoPacote.Location = new Point(198, 248);
            TxtPrecoPacote.Name = "TxtPrecoPacote";
            TxtPrecoPacote.PlaceholderText = "Digite o preço do pacote";
            TxtPrecoPacote.Size = new Size(409, 23);
            TxtPrecoPacote.TabIndex = 17;
            // 
            // PacoteForms
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1177, 733);
            Controls.Add(TxtPrecoPacote);
            Controls.Add(LblPrecosPacote);
            Controls.Add(TxtAcessosPacote);
            Controls.Add(LblAcessosPacote);
            Controls.Add(btnSalvar);
            Controls.Add(btnNovo);
            Controls.Add(grdPacotes);
            Controls.Add(ChkJogosPacotes);
            Controls.Add(label3);
            Controls.Add(txtNomePacote);
            Controls.Add(txtID);
            Controls.Add(LblNomePacote);
            Controls.Add(Lbl_IdPacote);
            Margin = new Padding(3, 2, 3, 2);
            Name = "PacoteForms";
            Text = "Cadastro de Pacotes";
            Load += PacoteForms_Load;
            ((System.ComponentModel.ISupportInitialize)grdPacotes).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtNomePacote;
        private TextBox txtID;
        private Label LblNomePacote;
        private Label label3;
        private CheckedListBox ChkJogosPacotes;
        private DataGridView grdPacotes;
        private Button btnSalvar;
        private Button btnNovo;
        private Label Lbl_IdPacote;
        private Label LblAcessosPacote;
        private TextBox TxtAcessosPacote;
        private Label LblPrecosPacote;
        private TextBox TxtPrecoPacote;
        private DataGridViewTextBoxColumn ID;
        private DataGridViewTextBoxColumn Pacote;
        private DataGridViewTextBoxColumn Acessos;
        private DataGridViewTextBoxColumn Preco;
        private DataGridViewTextBoxColumn JogosPacote;
    }
}