﻿namespace PrototipoMessier
{
    partial class JogosForms
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            LblNomeJogo = new Label();
            LblDescricao = new Label();
            TxtNome = new TextBox();
            TxtDescricao = new TextBox();
            btnNovo = new Button();
            btnSalvar = new Button();
            grdJogos = new DataGridView();
            ID = new DataGridViewTextBoxColumn();
            Nome = new DataGridViewTextBoxColumn();
            Tema = new DataGridViewTextBoxColumn();
            faixa_etária = new DataGridViewTextBoxColumn();
            Status = new DataGridViewTextBoxColumn();
            Descricao = new DataGridViewTextBoxColumn();
            LblTema = new Label();
            TxtTema = new TextBox();
            LblFaixaEtaria = new Label();
            TxtFaixaEtaria = new TextBox();
            LblStatus = new Label();
            TxtID = new TextBox();
            Lbl_Id = new Label();
            ChkAtivoJogos = new CheckBox();
            ChkDesativoJogos = new CheckBox();
            ((System.ComponentModel.ISupportInitialize)grdJogos).BeginInit();
            SuspendLayout();
            // 
            // LblNomeJogo
            // 
            LblNomeJogo.AutoSize = true;
            LblNomeJogo.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LblNomeJogo.Location = new Point(67, 76);
            LblNomeJogo.Name = "LblNomeJogo";
            LblNomeJogo.Size = new Size(126, 21);
            LblNomeJogo.TabIndex = 1;
            LblNomeJogo.Text = "Nome do Jogo:";
            LblNomeJogo.Click += label2_Click_2;
            // 
            // LblDescricao
            // 
            LblDescricao.AutoSize = true;
            LblDescricao.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LblDescricao.Location = new Point(67, 276);
            LblDescricao.Name = "LblDescricao";
            LblDescricao.Size = new Size(88, 21);
            LblDescricao.TabIndex = 2;
            LblDescricao.Text = "Descrição:";
            // 
            // TxtNome
            // 
            TxtNome.Location = new Point(199, 78);
            TxtNome.Margin = new Padding(3, 2, 3, 2);
            TxtNome.Name = "TxtNome";
            TxtNome.PlaceholderText = "Digite o nome do jogo";
            TxtNome.Size = new Size(413, 23);
            TxtNome.TabIndex = 4;
            TxtNome.TextChanged += TxtNome_TextChanged;
            // 
            // TxtDescricao
            // 
            TxtDescricao.Location = new Point(199, 276);
            TxtDescricao.Margin = new Padding(3, 2, 3, 2);
            TxtDescricao.Multiline = true;
            TxtDescricao.Name = "TxtDescricao";
            TxtDescricao.Size = new Size(409, 80);
            TxtDescricao.TabIndex = 5;
            TxtDescricao.TextChanged += TxtDescricao_TextChanged;
            // 
            // btnNovo
            // 
            btnNovo.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnNovo.Location = new Point(67, 566);
            btnNovo.Margin = new Padding(3, 2, 3, 2);
            btnNovo.Name = "btnNovo";
            btnNovo.Size = new Size(82, 22);
            btnNovo.TabIndex = 6;
            btnNovo.Text = "Novo";
            btnNovo.UseVisualStyleBackColor = true;
            btnNovo.Click += btnNovo_Click;
            // 
            // btnSalvar
            // 
            btnSalvar.Location = new Point(733, 567);
            btnSalvar.Margin = new Padding(3, 2, 3, 2);
            btnSalvar.Name = "btnSalvar";
            btnSalvar.Size = new Size(82, 22);
            btnSalvar.TabIndex = 7;
            btnSalvar.Text = "Salvar";
            btnSalvar.UseVisualStyleBackColor = true;
            btnSalvar.Click += btnSalvar_Click;
            // 
            // grdJogos
            // 
            grdJogos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            grdJogos.Columns.AddRange(new DataGridViewColumn[] { ID, Nome, Tema, faixa_etária, Status, Descricao });
            grdJogos.Location = new Point(67, 386);
            grdJogos.Margin = new Padding(3, 2, 3, 2);
            grdJogos.Name = "grdJogos";
            grdJogos.RowHeadersWidth = 51;
            grdJogos.Size = new Size(748, 167);
            grdJogos.TabIndex = 8;
            grdJogos.CellContentClick += grdJogos_CellContentClick;
            // 
            // ID
            // 
            ID.HeaderText = "ID";
            ID.MaxInputLength = 3;
            ID.MinimumWidth = 6;
            ID.Name = "ID";
            ID.ReadOnly = true;
            ID.Width = 60;
            // 
            // Nome
            // 
            Nome.HeaderText = "Nome";
            Nome.MaxInputLength = 20;
            Nome.MinimumWidth = 6;
            Nome.Name = "Nome";
            Nome.ReadOnly = true;
            Nome.Width = 200;
            // 
            // Tema
            // 
            Tema.HeaderText = "Tema";
            Tema.Name = "Tema";
            Tema.ReadOnly = true;
            // 
            // faixa_etária
            // 
            faixa_etária.HeaderText = "Faixa Etária";
            faixa_etária.Name = "faixa_etária";
            faixa_etária.ReadOnly = true;
            // 
            // Status
            // 
            Status.HeaderText = "Status";
            Status.Name = "Status";
            Status.ReadOnly = true;
            // 
            // Descricao
            // 
            Descricao.HeaderText = "Descrição";
            Descricao.MinimumWidth = 6;
            Descricao.Name = "Descricao";
            Descricao.ReadOnly = true;
            Descricao.Width = 300;
            // 
            // LblTema
            // 
            LblTema.AutoSize = true;
            LblTema.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LblTema.Location = new Point(67, 123);
            LblTema.Name = "LblTema";
            LblTema.Size = new Size(55, 21);
            LblTema.TabIndex = 9;
            LblTema.Text = "Tema:";
            LblTema.Click += lblTema_Click;
            // 
            // TxtTema
            // 
            TxtTema.Location = new Point(199, 121);
            TxtTema.Name = "TxtTema";
            TxtTema.PlaceholderText = "Digite o tema do jogo";
            TxtTema.Size = new Size(413, 23);
            TxtTema.TabIndex = 10;
            TxtTema.TextChanged += TxtTema_TextChanged;
            // 
            // LblFaixaEtaria
            // 
            LblFaixaEtaria.AutoSize = true;
            LblFaixaEtaria.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LblFaixaEtaria.Location = new Point(67, 170);
            LblFaixaEtaria.Name = "LblFaixaEtaria";
            LblFaixaEtaria.Size = new Size(102, 21);
            LblFaixaEtaria.TabIndex = 11;
            LblFaixaEtaria.Text = "Faixa Etária:";
            LblFaixaEtaria.Click += label4_Click;
            // 
            // TxtFaixaEtaria
            // 
            TxtFaixaEtaria.Location = new Point(199, 168);
            TxtFaixaEtaria.Name = "TxtFaixaEtaria";
            TxtFaixaEtaria.PlaceholderText = "Digite a faixa etária em anos";
            TxtFaixaEtaria.Size = new Size(413, 23);
            TxtFaixaEtaria.TabIndex = 12;
            TxtFaixaEtaria.TextChanged += textBox1_TextChanged;
            // 
            // LblStatus
            // 
            LblStatus.AutoSize = true;
            LblStatus.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LblStatus.Location = new Point(67, 224);
            LblStatus.Name = "LblStatus";
            LblStatus.Size = new Size(65, 21);
            LblStatus.TabIndex = 13;
            LblStatus.Text = "Status: ";
            // 
            // TxtID
            // 
            TxtID.Location = new Point(199, 26);
            TxtID.Margin = new Padding(3, 2, 3, 2);
            TxtID.Name = "TxtID";
            TxtID.PlaceholderText = "Digite seu ID";
            TxtID.Size = new Size(413, 23);
            TxtID.TabIndex = 3;
            TxtID.TextChanged += TxtID_TextChanged;
            // 
            // Lbl_Id
            // 
            Lbl_Id.AutoSize = true;
            Lbl_Id.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Lbl_Id.Location = new Point(67, 28);
            Lbl_Id.Name = "Lbl_Id";
            Lbl_Id.Size = new Size(31, 21);
            Lbl_Id.TabIndex = 0;
            Lbl_Id.Text = "ID:";
            Lbl_Id.Click += label1_Click;
            // 
            // ChkAtivoJogos
            // 
            ChkAtivoJogos.AutoSize = true;
            ChkAtivoJogos.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            ChkAtivoJogos.Location = new Point(199, 224);
            ChkAtivoJogos.Name = "ChkAtivoJogos";
            ChkAtivoJogos.Size = new Size(65, 25);
            ChkAtivoJogos.TabIndex = 14;
            ChkAtivoJogos.Text = "Ativo";
            ChkAtivoJogos.UseVisualStyleBackColor = true;
            ChkAtivoJogos.CheckedChanged += ChkAtivoJogos_CheckedChanged;
            // 
            // ChkDesativoJogos
            // 
            ChkDesativoJogos.AutoSize = true;
            ChkDesativoJogos.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            ChkDesativoJogos.Location = new Point(313, 224);
            ChkDesativoJogos.Name = "ChkDesativoJogos";
            ChkDesativoJogos.Size = new Size(106, 25);
            ChkDesativoJogos.TabIndex = 15;
            ChkDesativoJogos.Text = "Desativado";
            ChkDesativoJogos.UseVisualStyleBackColor = true;
            ChkDesativoJogos.CheckedChanged += ChkDesativoJogos_CheckedChanged;
            // 
            // JogosForms
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Window;
            ClientSize = new Size(829, 733);
            Controls.Add(ChkDesativoJogos);
            Controls.Add(ChkAtivoJogos);
            Controls.Add(LblStatus);
            Controls.Add(TxtFaixaEtaria);
            Controls.Add(LblFaixaEtaria);
            Controls.Add(TxtTema);
            Controls.Add(LblTema);
            Controls.Add(grdJogos);
            Controls.Add(btnSalvar);
            Controls.Add(btnNovo);
            Controls.Add(TxtDescricao);
            Controls.Add(TxtNome);
            Controls.Add(TxtID);
            Controls.Add(LblDescricao);
            Controls.Add(LblNomeJogo);
            Controls.Add(Lbl_Id);
            Margin = new Padding(3, 2, 3, 2);
            Name = "JogosForms";
            Text = "Cadastro de Jogos";
            Load += JogosForms_Load;
            ((System.ComponentModel.ISupportInitialize)grdJogos).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label LblNomeJogo;
        private Label LblDescricao;
        private TextBox TxtNome;
        private TextBox TxtDescricao;
        private Button btnNovo;
        private Button btnSalvar;
        private DataGridView grdJogos;
        private Label LblTema;
        private TextBox TxtTema;
        private Label LblFaixaEtaria;
        private TextBox TxtFaixaEtaria;
        private Label LblStatus;
        private DataGridViewTextBoxColumn ID;
        private DataGridViewTextBoxColumn Nome;
        private DataGridViewTextBoxColumn Tema;
        private DataGridViewTextBoxColumn faixa_etária;
        private DataGridViewTextBoxColumn Status;
        private DataGridViewTextBoxColumn Descricao;
        private TextBox TxtID;
        private Label Lbl_Id;
        private CheckBox ChkAtivoJogos;
        private CheckBox ChkDesativoJogos;
    }
}