﻿namespace PrototipoMessier
{
    partial class EscolaForms
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Lbl_IdEscola = new Label();
            LblNomeEscola = new Label();
            LblCnpj = new Label();
            LblStatus = new Label();
            LblDataCad = new Label();
            TxtNomeEscola = new TextBox();
            TxtCnpj = new TextBox();
            TxtIdEscola = new TextBox();
            ChkAtivo = new CheckBox();
            ChkDesativo = new CheckBox();
            CmbPacoteAdq = new ComboBox();
            LblPacoteAdq = new Label();
            GrdEscolas = new DataGridView();
            ID = new DataGridViewTextBoxColumn();
            NomeEscola = new DataGridViewTextBoxColumn();
            Cnpj = new DataGridViewTextBoxColumn();
            Status = new DataGridViewTextBoxColumn();
            DataCadastro = new DataGridViewTextBoxColumn();
            PacoteAdquirido = new DataGridViewTextBoxColumn();
            IPsAutorizados = new DataGridViewTextBoxColumn();
            Lbl_IpsAutorizado = new Label();
            BtnNovoEscola = new Button();
            BtnSalvarEscola = new Button();
            CmbIps = new ComboBox();
            DateDataCad = new DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)GrdEscolas).BeginInit();
            SuspendLayout();
            // 
            // Lbl_IdEscola
            // 
            Lbl_IdEscola.AutoSize = true;
            Lbl_IdEscola.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Lbl_IdEscola.Location = new Point(67, 29);
            Lbl_IdEscola.Name = "Lbl_IdEscola";
            Lbl_IdEscola.Size = new Size(31, 21);
            Lbl_IdEscola.TabIndex = 0;
            Lbl_IdEscola.Text = "ID:";
            // 
            // LblNomeEscola
            // 
            LblNomeEscola.AutoSize = true;
            LblNomeEscola.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LblNomeEscola.Location = new Point(67, 77);
            LblNomeEscola.Name = "LblNomeEscola";
            LblNomeEscola.Size = new Size(136, 21);
            LblNomeEscola.TabIndex = 1;
            LblNomeEscola.Text = "Nome da Escola:";
            // 
            // LblCnpj
            // 
            LblCnpj.AutoSize = true;
            LblCnpj.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LblCnpj.Location = new Point(73, 132);
            LblCnpj.Name = "LblCnpj";
            LblCnpj.Size = new Size(53, 21);
            LblCnpj.TabIndex = 2;
            LblCnpj.Text = "CNPJ:";
            // 
            // LblStatus
            // 
            LblStatus.AutoSize = true;
            LblStatus.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LblStatus.Location = new Point(67, 191);
            LblStatus.Name = "LblStatus";
            LblStatus.Size = new Size(61, 21);
            LblStatus.TabIndex = 3;
            LblStatus.Text = "Status:";
            // 
            // LblDataCad
            // 
            LblDataCad.AutoSize = true;
            LblDataCad.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LblDataCad.Location = new Point(67, 238);
            LblDataCad.Name = "LblDataCad";
            LblDataCad.Size = new Size(144, 21);
            LblDataCad.TabIndex = 4;
            LblDataCad.Text = "Data de Cadastro:";
            // 
            // TxtNomeEscola
            // 
            TxtNomeEscola.Location = new Point(211, 79);
            TxtNomeEscola.Name = "TxtNomeEscola";
            TxtNomeEscola.PlaceholderText = "Digite o nome da Escola";
            TxtNomeEscola.Size = new Size(303, 23);
            TxtNomeEscola.TabIndex = 5;
            TxtNomeEscola.TextChanged += TxtNomeEscola_TextChanged;
            // 
            // TxtCnpj
            // 
            TxtCnpj.Location = new Point(211, 134);
            TxtCnpj.Name = "TxtCnpj";
            TxtCnpj.PlaceholderText = "XXX.XXX.XXX-55";
            TxtCnpj.Size = new Size(307, 23);
            TxtCnpj.TabIndex = 6;
            // 
            // TxtIdEscola
            // 
            TxtIdEscola.Location = new Point(211, 31);
            TxtIdEscola.Name = "TxtIdEscola";
            TxtIdEscola.PlaceholderText = "Digite seu ID";
            TxtIdEscola.Size = new Size(303, 23);
            TxtIdEscola.TabIndex = 8;
            TxtIdEscola.TextChanged += TxtIdEscola_TextChanged;
            // 
            // ChkAtivo
            // 
            ChkAtivo.AutoSize = true;
            ChkAtivo.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            ChkAtivo.Location = new Point(220, 191);
            ChkAtivo.Name = "ChkAtivo";
            ChkAtivo.Size = new Size(65, 25);
            ChkAtivo.TabIndex = 9;
            ChkAtivo.Text = "Ativo";
            ChkAtivo.UseVisualStyleBackColor = true;
            ChkAtivo.CheckedChanged += ChkAtivo_CheckedChanged;
            // 
            // ChkDesativo
            // 
            ChkDesativo.AutoSize = true;
            ChkDesativo.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            ChkDesativo.Location = new Point(324, 191);
            ChkDesativo.Name = "ChkDesativo";
            ChkDesativo.Size = new Size(106, 25);
            ChkDesativo.TabIndex = 10;
            ChkDesativo.Text = "Desativado";
            ChkDesativo.UseVisualStyleBackColor = true;
            ChkDesativo.CheckedChanged += ChkDesativo_CheckedChanged;
            // 
            // CmbPacoteAdq
            // 
            CmbPacoteAdq.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            CmbPacoteAdq.FormattingEnabled = true;
            CmbPacoteAdq.Items.AddRange(new object[] { "Pacote Básico", "Pacote Intermediário", "Pacote Premium" });
            CmbPacoteAdq.Location = new Point(220, 296);
            CmbPacoteAdq.Name = "CmbPacoteAdq";
            CmbPacoteAdq.Size = new Size(139, 23);
            CmbPacoteAdq.TabIndex = 11;
            CmbPacoteAdq.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // LblPacoteAdq
            // 
            LblPacoteAdq.AutoSize = true;
            LblPacoteAdq.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LblPacoteAdq.Location = new Point(67, 294);
            LblPacoteAdq.Name = "LblPacoteAdq";
            LblPacoteAdq.Size = new Size(147, 21);
            LblPacoteAdq.TabIndex = 12;
            LblPacoteAdq.Text = "Pacote Adquirido:";
            LblPacoteAdq.Click += LblPacoteAdq_Click;
            // 
            // GrdEscolas
            // 
            GrdEscolas.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            GrdEscolas.Columns.AddRange(new DataGridViewColumn[] { ID, NomeEscola, Cnpj, Status, DataCadastro, PacoteAdquirido, IPsAutorizados });
            GrdEscolas.Location = new Point(73, 407);
            GrdEscolas.Name = "GrdEscolas";
            GrdEscolas.Size = new Size(870, 107);
            GrdEscolas.TabIndex = 13;
            GrdEscolas.CellContentClick += dataGridView1_CellContentClick;
            // 
            // ID
            // 
            ID.HeaderText = "ID";
            ID.Name = "ID";
            // 
            // NomeEscola
            // 
            NomeEscola.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            NomeEscola.HeaderText = "Nome Escola";
            NomeEscola.Name = "NomeEscola";
            // 
            // Cnpj
            // 
            Cnpj.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            Cnpj.HeaderText = "CNPJ";
            Cnpj.Name = "Cnpj";
            // 
            // Status
            // 
            Status.HeaderText = "Status";
            Status.Name = "Status";
            // 
            // DataCadastro
            // 
            DataCadastro.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            DataCadastro.HeaderText = "Data de Cadastro";
            DataCadastro.Name = "DataCadastro";
            // 
            // PacoteAdquirido
            // 
            PacoteAdquirido.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            PacoteAdquirido.HeaderText = "Pacote Adquirido";
            PacoteAdquirido.Name = "PacoteAdquirido";
            // 
            // IPsAutorizados
            // 
            IPsAutorizados.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            IPsAutorizados.HeaderText = "IPs Autorizados";
            IPsAutorizados.Name = "IPsAutorizados";
            // 
            // Lbl_IpsAutorizado
            // 
            Lbl_IpsAutorizado.AutoSize = true;
            Lbl_IpsAutorizado.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Lbl_IpsAutorizado.Location = new Point(73, 356);
            Lbl_IpsAutorizado.Name = "Lbl_IpsAutorizado";
            Lbl_IpsAutorizado.Size = new Size(130, 21);
            Lbl_IpsAutorizado.TabIndex = 14;
            Lbl_IpsAutorizado.Text = "IPs autorizados:";
            // 
            // BtnNovoEscola
            // 
            BtnNovoEscola.Location = new Point(73, 520);
            BtnNovoEscola.Name = "BtnNovoEscola";
            BtnNovoEscola.Size = new Size(75, 23);
            BtnNovoEscola.TabIndex = 15;
            BtnNovoEscola.Text = "Novo";
            BtnNovoEscola.UseVisualStyleBackColor = true;
            BtnNovoEscola.Click += button1_Click;
            // 
            // BtnSalvarEscola
            // 
            BtnSalvarEscola.Location = new Point(868, 520);
            BtnSalvarEscola.Name = "BtnSalvarEscola";
            BtnSalvarEscola.Size = new Size(75, 23);
            BtnSalvarEscola.TabIndex = 16;
            BtnSalvarEscola.Text = "Salvar";
            BtnSalvarEscola.UseVisualStyleBackColor = true;
            BtnSalvarEscola.Click += BtnSalvarEscola_Click;
            // 
            // CmbIps
            // 
            CmbIps.FormattingEnabled = true;
            CmbIps.Items.AddRange(new object[] { "192.168.0.10", "192.168.0.11", "192.168.0.12" });
            CmbIps.Location = new Point(220, 354);
            CmbIps.Name = "CmbIps";
            CmbIps.Size = new Size(139, 23);
            CmbIps.TabIndex = 17;
            // 
            // DateDataCad
            // 
            DateDataCad.Location = new Point(220, 238);
            DateDataCad.Name = "DateDataCad";
            DateDataCad.Size = new Size(254, 23);
            DateDataCad.TabIndex = 18;
            // 
            // EscolaForms
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1177, 733);
            Controls.Add(DateDataCad);
            Controls.Add(CmbIps);
            Controls.Add(BtnSalvarEscola);
            Controls.Add(BtnNovoEscola);
            Controls.Add(Lbl_IpsAutorizado);
            Controls.Add(GrdEscolas);
            Controls.Add(LblPacoteAdq);
            Controls.Add(CmbPacoteAdq);
            Controls.Add(ChkDesativo);
            Controls.Add(ChkAtivo);
            Controls.Add(TxtIdEscola);
            Controls.Add(TxtCnpj);
            Controls.Add(TxtNomeEscola);
            Controls.Add(LblDataCad);
            Controls.Add(LblStatus);
            Controls.Add(LblCnpj);
            Controls.Add(LblNomeEscola);
            Controls.Add(Lbl_IdEscola);
            Name = "EscolaForms";
            Text = "EscolaForms";
            ((System.ComponentModel.ISupportInitialize)GrdEscolas).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label Lbl_IdEscola;
        private Label LblNomeEscola;
        private Label LblCnpj;
        private Label LblStatus;
        private Label LblDataCad;
        private TextBox TxtNomeEscola;
        private TextBox TxtCnpj;
        private TextBox TxtIdEscola;
        private CheckBox ChkAtivo;
        private CheckBox ChkDesativo;
        private ComboBox CmbPacoteAdq;
        private Label LblPacoteAdq;
        private DataGridView GrdEscolas;
        private Label Lbl_IpsAutorizado;
        private Button BtnNovoEscola;
        private Button BtnSalvarEscola;
        private ComboBox CmbIps;
        private DateTimePicker DateDataCad;
        private DataGridViewTextBoxColumn ID;
        private DataGridViewTextBoxColumn NomeEscola;
        private DataGridViewTextBoxColumn Cnpj;
        private DataGridViewTextBoxColumn Status;
        private DataGridViewTextBoxColumn DataCadastro;
        private DataGridViewTextBoxColumn PacoteAdquirido;
        private DataGridViewTextBoxColumn IPsAutorizados;
    }
}