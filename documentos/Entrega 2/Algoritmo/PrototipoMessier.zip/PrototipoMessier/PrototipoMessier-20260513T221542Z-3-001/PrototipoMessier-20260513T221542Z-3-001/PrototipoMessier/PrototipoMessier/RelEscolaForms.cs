﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrototipoMessier
{
    public partial class RelEscolaForms : Form
    {
        public RelEscolaForms()
        {
            InitializeComponent();
        }

        private void btnImprimir_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Enviando relatório para a impressora...", "Imprimir", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void txtRel_TextChanged(object sender, EventArgs e)
        {

        }

        private void RelEscolaForms_Load(object sender, EventArgs e)
        {
           
            dgvRelatorios.Columns.Add("Escola", "Escola");
            dgvRelatorios.Columns.Add("Pacote", "Pacote Contratado");
            dgvRelatorios.Columns.Add("Limite", "Limite Mensal");
            dgvRelatorios.Columns.Add("Consumo", "Consumo Atual");
            dgvRelatorios.Columns.Add("Percentual", "% de Uso");


            dgvRelatorios.Rows.Add("Escola 1", "Básico", "100 acessos", "20", "20%");
            dgvRelatorios.Rows.Add("Escola 2", "Intermediário", "250 acessos", "125", "50%");
            dgvRelatorios.Rows.Add("Escola 3", "Premium", "500 acessos", "450", "90%");
            dgvRelatorios.Rows.Add("Escola 4", "Básico", "100 acessos", "95", "95%");
            dgvRelatorios.Rows.Add("Escola 5", "Premium", "500 acessos", "100", "20%");
            dgvRelatorios.Rows.Add("Escola 6", "Intermediário", "250 acessos", "240", "96%");
            dgvRelatorios.Rows.Add("Escola 7", "Premium", "500 acessos", "500", "100%"); 
        }
    }
}
