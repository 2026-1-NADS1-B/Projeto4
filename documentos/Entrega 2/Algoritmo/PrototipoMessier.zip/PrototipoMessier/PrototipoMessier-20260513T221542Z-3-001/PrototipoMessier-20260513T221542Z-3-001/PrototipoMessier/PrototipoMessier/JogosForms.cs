﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrototipoMessier
{
    public partial class JogosForms : Form
    {
        public JogosForms()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            TxtID.Clear();
            TxtNome.Clear();
            TxtDescricao.Clear();
            TxtTema.Clear();
            TxtFaixaEtaria.Clear();
            ChkAtivoJogos.Checked = true;
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            string status = ChkAtivoJogos.Checked ? "Ativo" : "Inativo";

            grdJogos.Rows.Add(
                TxtID.Text, 
                TxtNome.Text, 
                TxtTema.Text, 
                TxtFaixaEtaria.Text,
                status,
                TxtDescricao.Text);
        }

        private void lblTema_Click(object sender, EventArgs e)
        {

        }

        private void grdJogos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void JogosForms_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void label2_Click_2(object sender, EventArgs e)
        {

        }

        private void TxtID_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtNome_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtTema_TextChanged(object sender, EventArgs e)
        {

        }

        private void ChkAtivoJogos_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void ChkDesativoJogos_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void TxtDescricao_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
