﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrototipoMessier
{
    public partial class LoginForms : Form
    {
        public LoginForms()
        {
            InitializeComponent();
        }


        private void BtnEntrar_Click(object sender, EventArgs e)
        {
            Form1 frmMenu = new Form1();
            this.Hide();
            frmMenu.ShowDialog();
            this.Close();
        }


        private void LblUser_Click(object sender, EventArgs e)
        {

        }

        private void TxtSenha_TextChanged(object sender, EventArgs e)
        {

        }

        private void LoginForms_Load(object sender, EventArgs e)
        {

        }

        private void TxtIPLogin_TextChanged(object sender, EventArgs e)
        {

        }

        private void LbL_IpLogin_Click(object sender, EventArgs e)
        {

        }
    }
}