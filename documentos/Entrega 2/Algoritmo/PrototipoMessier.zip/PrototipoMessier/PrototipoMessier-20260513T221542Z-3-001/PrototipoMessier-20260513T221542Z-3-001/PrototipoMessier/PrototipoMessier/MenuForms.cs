namespace PrototipoMessier
{

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void AbrirFormNoPainel(Form formFilho)
        {
            if (this.pnlConteudo.Controls.Count > 0)
                this.pnlConteudo.Controls.RemoveAt(0);

            formFilho.TopLevel = false;
            formFilho.FormBorderStyle = FormBorderStyle.None;
            formFilho.Dock = DockStyle.Fill;
            this.pnlConteudo.Controls.Add(formFilho);
            this.pnlConteudo.Tag = formFilho;
            formFilho.Show();
        }

        private void btnCatalogo_Click(object sender, EventArgs e)
        {
            AbrirFormNoPainel(new CatalogoForms());
        }

        private void btnCadastroDeGames_Click(object sender, EventArgs e)
        {
            AbrirFormNoPainel(new JogosForms());
        }

        private void btnEscolas_Click(object sender, EventArgs e)
        {
            AbrirFormNoPainel(new EscolaForms());
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnRelatorios_Click(object sender, EventArgs e)
        {
            AbrirFormNoPainel(new RelEscolaForms());
        }

        private void btnGestaoDePacotes_Click(object sender, EventArgs e)
        {
            AbrirFormNoPainel(new PacoteForms());
        }

        private void btnDashboard_Click(object sender, EventArgs e)
        {
            AbrirFormNoPainel(new DashboardForms());
        }
    }
}