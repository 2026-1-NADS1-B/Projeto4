﻿namespace PrototipoMessier
{
    partial class CatalogoForms
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            BtnVoltar = new Button();
            flpCatalogo = new FlowLayoutPanel();
            SuspendLayout();
            // 
            // BtnVoltar
            // 
            BtnVoltar.Location = new Point(1090, 698);
            BtnVoltar.Name = "BtnVoltar";
            BtnVoltar.Size = new Size(75, 23);
            BtnVoltar.TabIndex = 0;
            BtnVoltar.Text = "Voltar";
            BtnVoltar.UseVisualStyleBackColor = true;
            BtnVoltar.Click += BtnVoltar_Click;
            // 
            // flpCatalogo
            // 
            flpCatalogo.AutoScroll = true;
            flpCatalogo.Location = new Point(2, 2);
            flpCatalogo.Name = "flpCatalogo";
            flpCatalogo.Size = new Size(1176, 732);
            flpCatalogo.TabIndex = 1;
            flpCatalogo.Paint += flpCatalogo_Paint;
            // 
            // CatalogoForms
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1177, 733);
            Controls.Add(BtnVoltar);
            Controls.Add(flpCatalogo);
            Name = "CatalogoForms";
            Text = "CatalogoForms";
            Load += CatalogoForms_Load;
            ResumeLayout(false);
        }

        #endregion

        private Button BtnVoltar;
        private FlowLayoutPanel flpCatalogo;
    }
}