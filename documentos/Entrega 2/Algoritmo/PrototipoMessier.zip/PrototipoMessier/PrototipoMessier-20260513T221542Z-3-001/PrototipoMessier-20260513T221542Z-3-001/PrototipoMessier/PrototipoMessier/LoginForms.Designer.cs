﻿namespace PrototipoMessier
{
    partial class LoginForms
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LoginForms));
            LblUser = new Label();
            LblSenha = new Label();
            TxtSenha = new TextBox();
            TxtUser = new TextBox();
            BtnEntrar = new Button();
            LbL_IpLogin = new Label();
            TxtIPLogin = new TextBox();
            SuspendLayout();
            // 
            // LblUser
            // 
            LblUser.AutoSize = true;
            LblUser.BackColor = SystemColors.ButtonHighlight;
            LblUser.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LblUser.ForeColor = SystemColors.MenuText;
            LblUser.Location = new Point(205, 187);
            LblUser.Name = "LblUser";
            LblUser.Size = new Size(91, 34);
            LblUser.TabIndex = 0;
            LblUser.Text = "Usuário:";
            LblUser.UseCompatibleTextRendering = true;
            LblUser.Click += LblUser_Click;
            // 
            // LblSenha
            // 
            LblSenha.AutoSize = true;
            LblSenha.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LblSenha.Location = new Point(205, 253);
            LblSenha.Name = "LblSenha";
            LblSenha.Size = new Size(79, 30);
            LblSenha.TabIndex = 1;
            LblSenha.Text = "Senha:";
            // 
            // TxtSenha
            // 
            TxtSenha.BackColor = SystemColors.ButtonFace;
            TxtSenha.Location = new Point(302, 260);
            TxtSenha.Name = "TxtSenha";
            TxtSenha.PasswordChar = '*';
            TxtSenha.Size = new Size(228, 23);
            TxtSenha.TabIndex = 2;
            TxtSenha.TextChanged += TxtSenha_TextChanged;
            // 
            // TxtUser
            // 
            TxtUser.BackColor = SystemColors.ButtonFace;
            TxtUser.Location = new Point(302, 196);
            TxtUser.Name = "TxtUser";
            TxtUser.Size = new Size(228, 23);
            TxtUser.TabIndex = 3;
            // 
            // BtnEntrar
            // 
            BtnEntrar.BackColor = SystemColors.ButtonFace;
            BtnEntrar.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            BtnEntrar.ForeColor = SystemColors.Highlight;
            BtnEntrar.Location = new Point(346, 388);
            BtnEntrar.Name = "BtnEntrar";
            BtnEntrar.Size = new Size(128, 31);
            BtnEntrar.TabIndex = 4;
            BtnEntrar.Text = "ENTRAR";
            BtnEntrar.TextAlign = ContentAlignment.TopCenter;
            BtnEntrar.UseVisualStyleBackColor = false;
            BtnEntrar.Click += BtnEntrar_Click;
            // 
            // LbL_IpLogin
            // 
            LbL_IpLogin.AutoSize = true;
            LbL_IpLogin.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LbL_IpLogin.Location = new Point(205, 315);
            LbL_IpLogin.Name = "LbL_IpLogin";
            LbL_IpLogin.Size = new Size(39, 30);
            LbL_IpLogin.TabIndex = 5;
            LbL_IpLogin.Text = "IP:";
            LbL_IpLogin.Click += LbL_IpLogin_Click;
            // 
            // TxtIPLogin
            // 
            TxtIPLogin.BackColor = SystemColors.ButtonFace;
            TxtIPLogin.Location = new Point(302, 324);
            TxtIPLogin.Name = "TxtIPLogin";
            TxtIPLogin.Size = new Size(228, 23);
            TxtIPLogin.TabIndex = 6;
            TxtIPLogin.TextChanged += TxtIPLogin_TextChanged;
            // 
            // LoginForms
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ButtonHighlight;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Zoom;
            ClientSize = new Size(800, 450);
            Controls.Add(TxtIPLogin);
            Controls.Add(LbL_IpLogin);
            Controls.Add(BtnEntrar);
            Controls.Add(TxtUser);
            Controls.Add(TxtSenha);
            Controls.Add(LblSenha);
            Controls.Add(LblUser);
            DoubleBuffered = true;
            Name = "LoginForms";
            Text = "LoginForms";
            Load += LoginForms_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label LblUser;
        private Label LblSenha;
        private TextBox TxtSenha;
        private TextBox TxtUser;
        private Button BtnEntrar;
        private Label LbL_IpLogin;
        private TextBox TxtIPLogin;
    }
}