﻿namespace PrototipoMessier
{
    partial class DashboardForms
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            flpCards = new FlowLayoutPanel();
            lblUsocritico = new Label();
            dgvAlertas = new DataGridView();
            panel1 = new Panel();
            dtpData = new DateTimePicker();
            lblConexao = new Label();
            lblUsuarioDashboard = new Label();
            ((System.ComponentModel.ISupportInitialize)dgvAlertas).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // flpCards
            // 
            flpCards.Location = new Point(40, 29);
            flpCards.Name = "flpCards";
            flpCards.Size = new Size(1125, 120);
            flpCards.TabIndex = 0;
            // 
            // lblUsocritico
            // 
            lblUsocritico.AutoSize = true;
            lblUsocritico.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblUsocritico.Location = new Point(40, 200);
            lblUsocritico.Name = "lblUsocritico";
            lblUsocritico.Size = new Size(387, 21);
            lblUsocritico.TabIndex = 1;
            lblUsocritico.Text = "Atenção: Escolas com uso crítico de limite mensal";
            // 
            // dgvAlertas
            // 
            dgvAlertas.BackgroundColor = Color.White;
            dgvAlertas.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvAlertas.GridColor = Color.LightGray;
            dgvAlertas.Location = new Point(40, 243);
            dgvAlertas.Name = "dgvAlertas";
            dgvAlertas.Size = new Size(1111, 429);
            dgvAlertas.TabIndex = 2;
            // 
            // panel1
            // 
            panel1.Controls.Add(dtpData);
            panel1.Controls.Add(lblConexao);
            panel1.Controls.Add(lblUsuarioDashboard);
            panel1.Location = new Point(895, 29);
            panel1.Name = "panel1";
            panel1.Size = new Size(270, 120);
            panel1.TabIndex = 3;
            // 
            // dtpData
            // 
            dtpData.Location = new Point(3, 74);
            dtpData.Name = "dtpData";
            dtpData.Size = new Size(253, 23);
            dtpData.TabIndex = 2;
            dtpData.ValueChanged += dateTimePicker1_ValueChanged;
            // 
            // lblConexao
            // 
            lblConexao.AutoSize = true;
            lblConexao.Location = new Point(13, 44);
            lblConexao.Name = "lblConexao";
            lblConexao.Size = new Size(110, 15);
            lblConexao.TabIndex = 1;
            lblConexao.Text = "Conexão: Localhost";
            lblConexao.Click += label1_Click;
            // 
            // lblUsuarioDashboard
            // 
            lblUsuarioDashboard.AutoSize = true;
            lblUsuarioDashboard.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblUsuarioDashboard.Location = new Point(13, 12);
            lblUsuarioDashboard.Name = "lblUsuarioDashboard";
            lblUsuarioDashboard.Size = new Size(134, 15);
            lblUsuarioDashboard.TabIndex = 0;
            lblUsuarioDashboard.Text = "Usuário: Administrador";
            // 
            // DashboardForms
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1177, 733);
            Controls.Add(panel1);
            Controls.Add(dgvAlertas);
            Controls.Add(lblUsocritico);
            Controls.Add(flpCards);
            Name = "DashboardForms";
            Text = "DashboardForms";
            Load += DashboardForms_Load;
            ((System.ComponentModel.ISupportInitialize)dgvAlertas).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblUsocritico;
        private FlowLayoutPanel flpCards;
        private DataGridView dgvAlertas;
        private Panel panel1;
        private Label lblConexao;
        private Label lblUsuarioDashboard;
        private DateTimePicker dtpData;
    }
}