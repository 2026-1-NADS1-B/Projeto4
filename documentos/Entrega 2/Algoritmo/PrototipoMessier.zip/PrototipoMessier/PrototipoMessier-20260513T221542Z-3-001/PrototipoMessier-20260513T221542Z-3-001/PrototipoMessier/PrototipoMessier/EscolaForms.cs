﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PrototipoMessier
{
    public partial class EscolaForms : Form
    {
        public EscolaForms()
        {
            InitializeComponent();
        }

        private void LblPacoteAdq_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            TxtIdEscola.Clear();
            TxtNomeEscola.Clear();
            TxtCnpj.Clear();
            ChkAtivo.Checked = true;
            TxtIdEscola.Focus();
        }

        private void BtnSalvarEscola_Click(object sender, EventArgs e)
        {
            string status = ChkAtivo.Checked ? "Ativo" : "Inativo";
            string PacoteADquirido = CmbPacoteAdq.Text;
            string IpsAutorizados = CmbIps.Text;


            GrdEscolas.Rows.Add(
            TxtIdEscola.Text,
            TxtNomeEscola.Text,
            TxtCnpj.Text,
            status,
            DateDataCad.Value.ToShortDateString(),
            PacoteADquirido,
            IpsAutorizados
            );
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void TxtIdEscola_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtNomeEscola_TextChanged(object sender, EventArgs e)
        {

        }

        private void ChkAtivo_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void ChkDesativo_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}

