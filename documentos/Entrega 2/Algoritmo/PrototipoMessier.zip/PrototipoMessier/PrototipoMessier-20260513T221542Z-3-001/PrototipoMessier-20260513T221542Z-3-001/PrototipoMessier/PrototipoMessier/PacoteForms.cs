﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrototipoMessier
{
    public partial class PacoteForms : Form
    {
        public PacoteForms()
        {
            InitializeComponent();
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            // Copia os itens marcados para uma lista separada
            var jogos = ChkJogosPacotes.CheckedItems
                .Cast<object>()
                .Select(item => item.ToString())
                .ToList();

            // Junta os nomes
            string jogosSelecionados = string.Join(", ", jogos);


            grdPacotes.Rows.Add(txtID.Text, txtNomePacote.Text, TxtAcessosPacote.Text, TxtPrecoPacote.Text, jogosSelecionados);

        }




        private void btnNovo_Click(object sender, EventArgs e)
        {
            txtNomePacote.Text = "";
            txtID.Text = "";
            for (int i = 0; i < ChkJogosPacotes.Items.Count; i++)
            {
                ChkJogosPacotes.SetItemCheckState(i, CheckState.Unchecked);
            }

        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void PacoteForms_Load(object sender, EventArgs e)
        {

        }

        private void grdPacotes_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtNomePacote_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtID_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
