﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrototipoMessier
{
    public partial class CatalogoForms : Form
    {

        public CatalogoForms()
        {
            InitializeComponent();

        }

        private void BtnVoltar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void flpCatalogo_Paint(object sender, PaintEventArgs e)
        {

        }

        private void CatalogoForms_Load(object sender, EventArgs e)
        {
            
            string[] jogos = { "Minecraft Educacional", "Forza Horizon (Física)", "Counter-Strike (Lógica)", "FIFA (Estatística)", "Zelda (História)" };
            string[] disciplinas = { "Matemática / Blocos", "Física / Cinemática", "Raciocínio Lógico", "Matemática Discreta", "História Geral" };
            string[] nomeImagens = { "minecraft", "forza", "cs", "fifa", "zelda" };
            flpCatalogo.Controls.Clear();

            for (int i = 0; i < jogos.Length; i++)
            {
                
                Panel card = new Panel();
                card.Size = new Size(200, 250);
                card.BackColor = Color.White;
                card.BorderStyle = BorderStyle.FixedSingle;
                card.Margin = new Padding(15); 

                
                PictureBox foto = new PictureBox();
                foto.Size = new Size(180, 110);
                foto.Location = new Point(10, 10);
                foto.BackColor = Color.LightGray; 
                foto.SizeMode = PictureBoxSizeMode.StretchImage;
                try
                {
                    
                    object img = Properties.Resources.ResourceManager.GetObject(nomeImagens[i]);
                    if (img != null)
                    {
                        foto.Image = (Image)img; 
                    }
                    else
                    {
                        foto.BackColor = Color.LightGray; 
                    }
                }
                catch
                {
                    foto.BackColor = Color.LightGray; 
                }


                Label titulo = new Label();
                titulo.Text = jogos[i];
                titulo.Font = new Font("Segoe UI", 11, FontStyle.Bold);
                titulo.Location = new Point(10, 130);
                titulo.Size = new Size(180, 25);

                
                Label tema = new Label();
                tema.Text = disciplinas[i];
                tema.Font = new Font("Segoe UI", 9, FontStyle.Regular);
                tema.ForeColor = Color.DimGray;
                tema.Location = new Point(10, 160);
                tema.Size = new Size(180, 20);

                
                Button btnAcessar = new Button();
                btnAcessar.Text = "Acessar Game";
                btnAcessar.Font = new Font("Segoe UI", 9, FontStyle.Bold);
                btnAcessar.Size = new Size(180, 35);
                btnAcessar.Location = new Point(10, 195);
                btnAcessar.FlatStyle = FlatStyle.Flat;
                btnAcessar.FlatAppearance.BorderSize = 0;
                btnAcessar.BackColor = Color.FromArgb(0, 0, 128); 
                btnAcessar.ForeColor = Color.White;

                
                string nomeJogo = jogos[i]; 
                btnAcessar.Click += (s, ev) => {
                    MessageBox.Show($"Acesso ao game '{nomeJogo}' registrado com sucesso!\nContador mensal incrementado.",
                                    "Simulação de Acesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                };

                
                card.Controls.Add(foto);
                card.Controls.Add(titulo);
                card.Controls.Add(tema);
                card.Controls.Add(btnAcessar);

                
                flpCatalogo.Controls.Add(card);
            }
        }
    }
}
