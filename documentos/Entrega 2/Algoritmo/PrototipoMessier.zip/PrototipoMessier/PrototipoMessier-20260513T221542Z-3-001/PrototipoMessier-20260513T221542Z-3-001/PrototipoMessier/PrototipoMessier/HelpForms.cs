﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PrototipoMessier
{
    public partial class HelpForms : Form
    {
        public HelpForms()
        {
            InitializeComponent();
        }

        private void HelpForms_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnJogos_Click(object sender, EventArgs e)
        {
            txtHelp.Text = "                 COMO CADASTRAR UM JOGO \r\n\r\n";
            txtHelp.Text += " O JOGO DIGITAL (GAME) É UMA IMPORTANTE FERRAMENTA EDUCACIONAL \r\n  ";
            txtHelp.Text += " Os Dados principais são o ID,NOME e DESCRIÇÃO \r\n";
            txtHelp.Text += " Os demais dados são OPCIONAIS";
        }

        private void btnPacote_Click(object sender, EventArgs e)
        {
            txtHelp.Text = "                 COMO CADASTRAR UM PACOTE \r\n\r\n";
            txtHelp.Text += " UM PACOTE É UM CONJUNTO DE JOGOS PARA LOCAÇÃO!! \r\n  ";
            txtHelp.Text += " Os Dados principais são o ID,NOME e DESCRIÇÃO E OS JOGOS QUE COMPÕEM O PACOTE \r\n";
            txtHelp.Text += " Os demais dados são OPCIONAIS";
        }
    }
}
